from setuptools import setup

setup(name='sm2kg',
        version='0.1',
        description='test desc',
        packages=['sm2kg'],
        include_package_data=True,
        zip_safe=False)
